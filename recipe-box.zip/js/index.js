"use strict";

var Header = React.createClass({
  displayName: "Header",

  render: function render() {
    return React.createElement(
      "div",
      null,
      React.createElement(
        "h1",
        null,
        "Header"
      )
    );
  }
});

var Footer = React.createClass({
  displayName: "Footer",

  render: function render() {
    return React.createElement(
      "div",
      null,
      React.createElement(
        "h1",
        null,
        "Footer"
      )
    );
  }
});
//return a map function but first get the object;

var Accordion = React.createClass({
  displayName: "Accordion",

  getInitialState: function getInitialState() {
    if (localStorage !== "undefined" && localStorage.getItem("_feuerbird29_recipes") !== "") {
      return this.state = {
        recipes: JSON.parse(localStorage.getItem("_feuerbird29_recipes"))
      };
    }
    return {
      recipes: [{
        title: "Black Coffee",
        img: "http://www.menshealth.com/sites/menshealth.com/files/coffee-mug.jpg",
        ingredients: "sun love and coffee",
        instructions: "Pour love and boil until it turns into sparkles"
      }, {
        title: "Red Coffee",
        img: "http://www.menshealth.com/sites/menshealth.com/files/coffee-mug.jpg",
        ingredients: "mountains, rain and coffee",
        instructions: "Ooh cry me a river, ooh cry me a river"
      }]
    };
  },
  handleEdit: function handleEdit() {},
  handleDelete: function handleDelete() {},
  handleSave: function handleSave() {},
  render: function render() {
    return React.createElement(
      "div",
      { className: "contaner-fluid" },
      React.createElement(
        "div",
        { className: "row" },
        React.createElement("div", { className: "col-sm-2" }),
        React.createElement(
          "div",
          { className: "panel-group col-sm-8" },
          React.createElement(
            "div",
            { className: "panel panel-default" },
            React.createElement(
              "div",
              { className: "panel-heading" },
              React.createElement(
                "h4",
                { className: "panel-title" },
                React.createElement(
                  "a",
                  { "data-toggle": "collapse", href: "#collapse2" },
                  React.createElement(
                    "button",
                    { className: "btn btn-primary" },
                    "Add Recipe"
                  )
                )
              )
            ),
            React.createElement(
              "div",
              { id: "collapse2", className: "panel-collapse collapse" },
              React.createElement(
                "div",
                { className: "panel-body" },
                React.createElement(
                  "form",
                  null,
                  React.createElement("input", { type: "text", placeholder: "Title..." }),
                  React.createElement("br", null),
                  React.createElement("input", { type: "url", placeholder: "Image URL..." }),
                  React.createElement("br", null),
                  React.createElement("textarea", { type: "text", placeholder: "Ingredients..." }),
                  React.createElement("br", null),
                  React.createElement("textarea", { type: "text", placeholder: "Instructions..." }),
                  React.createElement("br", null)
                )
              ),
              React.createElement(
                "div",
                { className: "panel-footer" },
                React.createElement(
                  "button",
                  { className: "btn btn-primary", onClick: this.handleSave },
                  "Save Recipe"
                )
              )
            )
          ),
          React.createElement(
            "div",
            { className: "panel panel-default" },
            React.createElement(
              "div",
              { className: "panel-heading" },
              React.createElement(
                "h4",
                { className: "panel-title" },
                React.createElement(
                  "a",
                  { "data-toggle": "collapse", href: "#collapse1" },
                  "Black Coffee"
                )
              )
            ),
            React.createElement(
              "div",
              { id: "collapse1", className: "panel-collapse collapse" },
              React.createElement(
                "div",
                { className: "panel-body" },
                "Coffee, water, love"
              ),
              React.createElement(
                "div",
                { className: "panel-footer" },
                React.createElement(
                  "button",
                  { className: "btn btn-primary", onClick: this.handleEdit },
                  "Edit"
                ),
                React.createElement(
                  "button",
                  {
                    className: "btn btn-primary",
                    onClick: this.handleDelete
                  },
                  "Delete"
                )
              )
            )
          )
        )
      )
    );
  }
});

var RecipeBox = React.createClass({
  displayName: "RecipeBox",

  render: function render() {
    return React.createElement(
      "div",
      null,
      React.createElement(Header, null),
      React.createElement(Accordion, null),
      React.createElement(Footer, null)
    );
  }
});

ReactDOM.render(React.createElement(RecipeBox, null), document.getElementById("app"));